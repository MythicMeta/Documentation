# Next Release

## What's planned for the next release (2.4)?

* [ ] Updated `mythic` PyPi package for scripting to leverage the new GraphQL interfaces instead of the old WebSockets.
* [ ] Removal of all old user interface, REST endpoints, and WebSockets
*

## How can I submit something to be added in the next release?

* Open up a feature request on the Mythic github page (https://github.com/its-a-feature/Mythic)
* Ask for it in the #mythic slack channel in the public Bloodhound slack
