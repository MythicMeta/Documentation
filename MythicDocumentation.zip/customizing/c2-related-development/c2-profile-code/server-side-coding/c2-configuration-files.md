# C2 Configuration Files

## Config.json

Every C2 Profile should have a `config.json` file located in their defined `server_folder_path` which contains all the fields an operator would need to configure.

This is the main way for an operator to do configurations of the C2 profile without having to connect to the server where Mythic is running. This can be any format in reality, the name just has to stay the same.
