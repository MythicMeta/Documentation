---
description: This page describes how messages flow within Mythic
---

# Message Flow

The following subpages have Mermaid sequence diagrams explaining how messages flow amongst the various microservices for Mythic when doing things like creating payloads, issuing tasks, and trasnferring files.
