# Expanded Callbacks

For any active callback, select the dropdown next to it and select "Expand Callback". This will open a new tab for that callback where you can actually view the tasking full screen with metadata on the side.

<figure><img src="../.gitbook/assets/Screenshot 2023-03-06 at 9.22.36 AM.png" alt=""><figcaption></figcaption></figure>
