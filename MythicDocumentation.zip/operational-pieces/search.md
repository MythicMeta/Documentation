# Search

## Where is it?

The operational search feature can be found by clicking the top "search" icon. From here you can search across callbacks, tasks, files, screenshots, keylogs, tokens, artifacts, and more.

## How is it used?

The search bar checks for what you type as a case insensitive grep.

![](<../.gitbook/assets/Screenshot 2023-03-06 at 8.37.16 AM.png>)

