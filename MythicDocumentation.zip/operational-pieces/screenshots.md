# Screenshots

## Where is it?

Screenshots for an entire operation can be accessed via the camera icon in the top bar or the search page.

## How to use it?

The screenshots display as they're coming in and will indicate how many chunks are left before you have the full image. At any point you can click on the image and view what's available so far.

